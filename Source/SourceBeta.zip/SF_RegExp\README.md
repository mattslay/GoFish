# ![](vfpx_mini.gif "VFPX") SF RegExp

---
This folder holds the code and helper.   
Include this to your project to use SF RegExp.